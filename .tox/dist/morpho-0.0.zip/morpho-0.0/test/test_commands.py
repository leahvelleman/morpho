from hypothesis import given
from hypothesis.strategies import lists, text
import morpho

@given(lists(text()), lists(text()))
def test_match(matches, herrings):
    acceptor = morpho.match(*matches)
    for match in matches:
        assert match in acceptor
    for herring in herrings:
        if herring not in matches:
            assert herring not in acceptor

