Morpho
======

Tools for developing finite state morphological models in Python.

Requires Foma, for which precompiled binaries can be found at https://fomafst.github.io/.
